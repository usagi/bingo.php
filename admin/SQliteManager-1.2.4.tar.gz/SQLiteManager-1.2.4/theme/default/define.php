<?php
/**
* Web based SQLite management
* Some Theme defines
* @package SQLiteManager
* @author Fr�d�ric HENNINOT
* @version $Id: define.php,v 1.8 2005/06/05 17:58:37 freddy78 Exp $ $Revision: 1.8 $
*/

$QueryResultAlign			= "center";
$displayQueryTitleColor = "lightblue";
$displayQueryBgColor 	= "#CCCCCC";

$browseColor1				= "#EEEEEE";
$browseColor2				= "#DDDDDD";
$browseColorOver			= "yellow";
$browseColorClick			= "lightgreen";

//$theme_author  = '<br/>Fr�d�ric HENNINOT';
//$theme_contact = 'mailto:fhenninot at freesurf.fr';
?>
