<?php
/**
* Web based SQLite management
* Some Theme defines
* @package SQLiteManager
* @author Fr�d�ric HENNINOT
* @version $Id: define.php,v 1.3 2005/06/05 17:58:37 freddy78 Exp $ $Revision: 1.3 $
*/

$QueryResultAlign			= "center";
$displayQueryTitleColor = "#e7dfce";
$displayQueryBgColor 	= "#e7dfce";

$browseColor1				= "#f7f3ef";
$browseColor2				= "#e7dfce";
$browseColorOver			= "";
$browseColorClick			= "";
?>
